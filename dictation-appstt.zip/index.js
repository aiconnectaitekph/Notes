/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI } from '@google/genai';
import { marked } from 'marked';

const MODEL_NAME = 'gemini-2.5-flash';

class VoiceNotesApp {
  constructor() {
    this.genAI = new GoogleGenAI({
      apiKey: process.env.API_KEY,
    });
    
    this.initDomElements();
    this.initEventListeners();
    this.initTheme();
    this.initTabNavigation();
    
    this.mediaRecorder = null;
    this.audioChunks = [];
    this.recordingState = 'idle'; // idle, recording, paused
    this.stream = null;
    this.fullRawTranscription = '';
    this.activeChunkPromises = [];

    this.audioContext = null;
    this.analyserNode = null;
    this.waveformDataArray = null;
    this.waveformDrawingId = null;

    this.updateUIForState('idle');
  }

  initDomElements() {
    // Header controls
    this.themeToggleButton = document.getElementById('themeToggleButton');
    this.themeToggleIcon = this.themeToggleButton.querySelector('i');

    // Source selection
    this.micButton = document.getElementById('micButton');
    this.uploadButton = document.getElementById('uploadButton');
    this.fileInput = document.getElementById('fileInput');
    
    // Main controls
    this.startButton = document.getElementById('startButton');
    this.pauseButton = document.getElementById('pauseButton');
    this.stopButton = document.getElementById('stopButton');
    this.recordingStatus = document.getElementById('recordingStatus');
    this.chunkStatus = document.getElementById('chunkStatus');

    // Waveform
    this.liveWaveformCanvas = document.getElementById('liveWaveformCanvas');
    this.liveWaveformCtx = this.liveWaveformCanvas.getContext('2d');
    
    // Transcript panels
    this.transcriptContainer = document.getElementById('transcriptContainer');
    this.polishedNote = document.getElementById('polishedNote');
    this.conversationLog = document.getElementById('conversationLog');

    this.setupCanvasDimensions();
  }

  initEventListeners() {
    this.themeToggleButton.addEventListener('click', () => this.toggleTheme());
    this.uploadButton.addEventListener('click', () => this.fileInput.click());
    this.fileInput.addEventListener('change', (e) => this.handleFileUpload(e));
    this.startButton.addEventListener('click', () => this.startRecording());
    this.stopButton.addEventListener('click', () => this.stopRecording());
    this.pauseButton.addEventListener('click', () => console.log('Pause functionality not implemented yet.'));
    document.getElementById('fetchUrlButton').addEventListener('click', () => alert('URL fetching not implemented yet.'));
    window.addEventListener('resize', () => this.handleResize());
  }

  handleResize() {
    this.setupCanvasDimensions();
  }

  setupCanvasDimensions() {
    if (!this.liveWaveformCanvas || !this.liveWaveformCtx) return;

    const canvas = this.liveWaveformCanvas;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    
    this.liveWaveformCtx.scale(dpr, dpr);
  }

  initTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
      document.body.classList.add('light-mode');
      this.themeToggleIcon.classList.replace('fa-sun', 'fa-moon');
    } else {
      document.body.classList.remove('light-mode');
      this.themeToggleIcon.classList.replace('fa-moon', 'fa-sun');
    }
  }

  toggleTheme() {
    document.body.classList.toggle('light-mode');
    if (document.body.classList.contains('light-mode')) {
      localStorage.setItem('theme', 'light');
      this.themeToggleIcon.classList.replace('fa-sun', 'fa-moon');
    } else {
      localStorage.setItem('theme', 'dark');
      this.themeToggleIcon.classList.replace('fa-moon', 'fa-sun');
    }
  }

  updateUIForState(newState) {
    this.recordingState = newState;

    this.startButton.disabled = this.recordingState === 'recording';
    this.pauseButton.disabled = this.recordingState !== 'recording';
    this.stopButton.disabled = this.recordingState === 'idle';
    
    this.uploadButton.disabled = this.recordingState === 'recording';
    
    if (this.recordingState === 'idle') {
      this.recordingStatus.textContent = 'Ready to record';
    } else if (this.recordingState === 'recording') {
      this.recordingStatus.textContent = 'Recording...';
    }
  }

  async handleFileUpload(event) {
    const input = event.target;
    if (!input.files || input.files.length === 0) return;
    
    const file = input.files[0];
    if (!file.type.startsWith('audio/')) {
      alert('Please select an audio file.');
      return;
    }

    this.resetTranscription();
    this.recordingStatus.textContent = 'Processing uploaded file...';
    this.updateUIForState('recording'); // Visually block controls
    
    try {
      const base64Audio = await this.fileToBase64(file);
      const transcription = await this.getTranscription(base64Audio, file.type);
      this.fullRawTranscription = transcription;
      this.addBubble(transcription, 'user');
      await this.getPolishedNote();
    } catch (err) {
      console.error('Error processing uploaded file:', err);
      this.addBubble(`Error processing file: ${err.message}`, 'error');
      this.recordingStatus.textContent = 'Error processing file.';
    } finally {
      input.value = '';
      this.updateUIForState('idle');
    }
  }

  async startRecording() {
    if (this.recordingState !== 'idle') return;

    this.resetTranscription();
    this.updateUIForState('recording');

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.setupAudioVisualizer();
      this.drawLiveWaveform();
      
      this.mediaRecorder = new MediaRecorder(this.stream, { mimeType: 'audio/webm' });
      
      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          const chunkPromise = this.processAudioChunk(event.data);
          this.activeChunkPromises.push(chunkPromise);
          chunkPromise.finally(() => {
            this.activeChunkPromises = this.activeChunkPromises.filter(p => p !== chunkPromise);
          });
        }
      };

      this.mediaRecorder.onstop = async () => {
        this.recordingStatus.textContent = 'Finalizing...';
        await Promise.all(this.activeChunkPromises);

        if (this.fullRawTranscription.trim()) {
            this.conversationLog.textContent = this.fullRawTranscription;
            await this.getPolishedNote();
            this.recordingStatus.textContent = 'Note polished.';
        } else {
            this.recordingStatus.textContent = 'No audio detected.';
        }
        
        this.stopLiveDisplay();
        this.updateUIForState('idle');
      };

      this.mediaRecorder.start(3000); // 3-second chunks
      
    } catch (error) {
      console.error('Error starting recording:', error);
      this.recordingStatus.textContent = 'Mic access denied or unavailable.';
      this.stopLiveDisplay();
      this.updateUIForState('idle');
    }
  }

  async stopRecording() {
    if (this.recordingState === 'recording') {
      this.mediaRecorder?.stop();
    }
  }
  
  async processAudioChunk(audioBlob) {
    const typingIndicator = this.addTypingIndicator();
    this.chunkStatus.textContent = `Chunk received...`;
    
    try {
        const base64Audio = await this.fileToBase64(audioBlob);
        const prompt = 'Transcribe this short audio clip precisely. Do not add any extra commentary, just the transcribed text.';
        const transcription = await this.getTranscription(base64Audio, audioBlob.type, prompt);
        
        if (transcription) {
            this.fullRawTranscription += transcription + ' ';
            this.addBubble(transcription, 'user');
        }
        this.chunkStatus.textContent = `Chunk processed.`;
    } catch (error) {
        console.error('Error processing audio chunk:', error);
        this.addBubble('Error transcribing chunk.', 'error');
        this.chunkStatus.textContent = `Chunk failed.`;
    } finally {
        typingIndicator.remove();
    }
  }

  async getTranscription(base64Audio, mimeType, prompt = 'Generate a complete, detailed transcript of this audio.') {
      try {
        const contents = [
          { text: prompt },
          { inlineData: { mimeType: mimeType, data: base64Audio } },
        ];
        const response = await this.genAI.models.generateContent({
            model: MODEL_NAME,
            contents: contents,
        });
        return response.text;
      } catch (error) {
        console.error('Error in getTranscription:', error);
        throw new Error('Failed to get transcription from API.');
      }
  }

  async getPolishedNote() {
    if (!this.fullRawTranscription.trim()) {
        this.polishedNote.textContent = '';
        return;
    }
    
    this.recordingStatus.textContent = 'Polishing note...';
    try {
        const prompt = `Take this raw transcription and create a polished, well-formatted note. Remove filler words, repetitions, and false starts. Format lists and headings using markdown. Maintain the original meaning. Raw transcription: ${this.fullRawTranscription}`;
        const response = await this.genAI.models.generateContent({
            model: MODEL_NAME,
            contents: [{text: prompt}],
        });
        const polishedText = response.text;
        this.polishedNote.innerHTML = marked.parse(polishedText);
        this.recordingStatus.textContent = 'Note polished.';
    } catch (error) {
        console.error('Error polishing note:', error);
        this.polishedNote.innerHTML = '<em>Error polishing note.</em>';
        this.recordingStatus.textContent = 'Polishing failed.';
    }
  }
  
  resetTranscription() {
    this.fullRawTranscription = '';
    this.transcriptContainer.innerHTML = `
      <div class="placeholder">
        <i class="fas fa-comment-dots"></i>
        <p>Live transcription will appear here</p>
      </div>`;
    this.polishedNote.innerHTML = '';
    this.conversationLog.textContent = '';
  }

  addBubble(text, type) { // type = 'user', 'error'
    this.transcriptContainer.querySelector('.placeholder')?.remove();
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${type}`;
    bubble.textContent = text;
    this.transcriptContainer.appendChild(bubble);
    this.transcriptContainer.parentElement.scrollTop = this.transcriptContainer.parentElement.scrollHeight;
  }

  addTypingIndicator() {
    this.transcriptContainer.querySelector('.placeholder')?.remove();
    const indicator = document.createElement('div');
    indicator.className = 'typing-indicator';
    indicator.innerHTML = '<span></span><span></span><span></span>';
    this.transcriptContainer.appendChild(indicator);
    this.transcriptContainer.parentElement.scrollTop = this.transcriptContainer.parentElement.scrollHeight;
    return indicator;
  }

  fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  }

  setupAudioVisualizer() {
    if (!this.stream || this.audioContext) return;
    this.audioContext = new AudioContext();
    const source = this.audioContext.createMediaStreamSource(this.stream);
    this.analyserNode = this.audioContext.createAnalyser();
    this.analyserNode.fftSize = 256;
    this.analyserNode.smoothingTimeConstant = 0.8;
    this.waveformDataArray = new Uint8Array(this.analyserNode.frequencyBinCount);
    source.connect(this.analyserNode);
  }

  drawLiveWaveform() {
    if (this.recordingState !== 'recording' || !this.analyserNode) {
      if (this.liveWaveformCtx) {
        const canvas = this.liveWaveformCanvas;
        this.liveWaveformCtx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
      }
      return;
    }

    this.waveformDrawingId = requestAnimationFrame(() => this.drawLiveWaveform());
    this.analyserNode.getByteTimeDomainData(this.waveformDataArray);
    
    const ctx = this.liveWaveformCtx;
    const canvas = this.liveWaveformCanvas;
    const logicalWidth = canvas.clientWidth;
    const logicalHeight = canvas.clientHeight;
    
    ctx.clearRect(0, 0, logicalWidth, logicalHeight);
    
    ctx.lineWidth = 2;
    ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-accent').trim();
    ctx.beginPath();
    
    const bufferLength = this.analyserNode.frequencyBinCount;
    const sliceWidth = logicalWidth / bufferLength;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
        const v = this.waveformDataArray[i] / 128.0;
        const y = v * logicalHeight / 2;
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
        x += sliceWidth;
    }
    
    ctx.lineTo(logicalWidth, logicalHeight / 2);
    ctx.stroke();
  }
  
  stopLiveDisplay() {
    if (this.waveformDrawingId) {
      cancelAnimationFrame(this.waveformDrawingId);
      this.waveformDrawingId = null;
    }
    if (this.audioContext && this.audioContext.state !== 'closed') {
        this.audioContext.close();
    }
    this.stream?.getTracks().forEach(track => track.stop());
    this.audioContext = null;
    this.stream = null;
    if (this.liveWaveformCtx) {
        const canvas = this.liveWaveformCanvas;
        this.liveWaveformCtx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
    }
  }
  
  initTabNavigation() {
    const tabContainer = document.querySelector(".final-outputs-panel");
    const tabButtons = tabContainer.querySelectorAll(".tab-button");
    const activeTabIndicator = tabContainer.querySelector(".active-tab-indicator");
    const noteContents = tabContainer.querySelectorAll(".note-content");

    const setActiveTab = (activeButton, skipAnimation = false) => {
      if (!activeButton || !activeTabIndicator) return;
      
      tabButtons.forEach((btn) => btn.classList.remove("active"));
      activeButton.classList.add("active");

      const tabName = activeButton.getAttribute("data-tab");
      noteContents.forEach((content) => content.classList.remove("active"));
      document.getElementById(tabName)?.classList.add("active");

      const originalTransition = activeTabIndicator.style.transition;
      activeTabIndicator.style.transition = skipAnimation ? "none" : "";
      
      activeTabIndicator.style.left = `${activeButton.offsetLeft}px`;
      activeTabIndicator.style.width = `${activeButton.offsetWidth}px`;

      if (skipAnimation) {
        requestAnimationFrame(() => {
          activeTabIndicator.style.transition = originalTransition;
        });
      }
    };
    
    tabButtons.forEach((button) => {
      button.addEventListener("click", () => setActiveTab(button));
    });

    // Set initial state
    setActiveTab(tabContainer.querySelector(".tab-button.active"), true);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (!process.env.API_KEY) {
    document.body.innerHTML = `<div style="font-family: sans-serif; text-align: center; padding: 2rem; color: #ff453a;">
      <h1>Configuration Error</h1>
      <p>API_KEY environment variable is not set. Please configure it to use the application.</p>
    </div>`;
    return;
  }
  new VoiceNotesApp();
});
